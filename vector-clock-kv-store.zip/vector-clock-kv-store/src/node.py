import socket
import threading
import json
import time
import uuid
from typing import Dict, Any, List

class DistributedKVNode:
    def __init__(self, node_id: int, total_nodes: int, host: str, port: int):
        self.node_id = node_id
        self.total_nodes = total_nodes
        self.host = host
        self.port = port
        
        # Vector clock and causal delivery components
        self.vector_clock = VectorClock(total_nodes, node_id)
        self.message_buffer = MessageBuffer()
        
        # Key-value store
        self.data_store = {}
        self.store_lock = threading.Lock()
        
        # Network components
        self.socket = None
        self.peers = {}  # {node_id: (host, port)}
        self.running = False
        
        # Start server
        self.start_server()
    
    def start_server(self):
        """Start the server to listen for incoming connections."""
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket.bind((self.host, self.port))
        self.socket.listen(10)
        self.running = True
        
        # Start server thread
        server_thread = threading.Thread(target=self._server_loop)
        server_thread.daemon = True
        server_thread.start()
        
        # Start causal delivery processor
        delivery_thread = threading.Thread(target=self._process_causal_delivery)
        delivery_thread.daemon = True
        delivery_thread.start()
        
        print(f"Node {self.node_id} started on {self.host}:{self.port}")
    
    def add_peer(self, peer_id: int, host: str, port: int):
        """Add a peer node."""
        self.peers[peer_id] = (host, port)
    
    def _server_loop(self):
        """Main server loop to handle incoming connections."""
        while self.running:
            try:
                client_socket, addr = self.socket.accept()
                client_thread = threading.Thread(
                    target=self._handle_client, 
                    args=(client_socket,)
                )
                client_thread.daemon = True
                client_thread.start()
            except Exception as e:
                if self.running:
                    print(f"Server error: {e}")
    
    def _handle_client(self, client_socket):
        """Handle individual client connections."""
        try:
            data = client_socket.recv(4096).decode('utf-8')
            message = json.loads(data)
            
            response = self._process_message(message)
            
            client_socket.send(json.dumps(response).encode('utf-8'))
        except Exception as e:
            print(f"Client handling error: {e}")
        finally:
            client_socket.close()
    
    def _process_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Process incoming messages based on type."""
        msg_type = message.get('type')
        
        if msg_type == 'write':
            return self._handle_write_request(message)
        elif msg_type == 'read':
            return self._handle_read_request(message)
        elif msg_type == 'replicate':
            return self._handle_replication(message)
        else:
            return {'status': 'error', 'message': 'Unknown message type'}
    
    def _handle_write_request(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Handle write requests from clients."""
        key = message.get('key')
        value = message.get('value')
        
        if not key or value is None:
            return {'status': 'error', 'message': 'Invalid key or value'}
        
        # Increment vector clock for local write
        self.vector_clock.increment()
        
        # Store locally
        with self.store_lock:
            self.data_store[key] = value
        
        # Create replication message
        replication_msg = CausalMessage(
            sender_id=self.node_id,
            message_type='replicate',
            key=key,
            value=value,
            vector_clock=self.vector_clock.get_clock(),
            message_id=str(uuid.uuid4())
        )
        
        # Replicate to all peers
        self._replicate_to_peers(replication_msg)
        
        return {
            'status': 'success',
            'message': f'Key {key} written successfully',
            'vector_clock': self.vector_clock.get_clock()
        }
    
    def _handle_read_request(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Handle read requests from clients."""
        key = message.get('key')
        
        if not key:
            return {'status': 'error', 'message': 'Invalid key'}
        
        # Increment vector clock for local read
        self.vector_clock.increment()
        
        with self.store_lock:
            value = self.data_store.get(key)
        
        if value is None:
            return {
                'status': 'not_found',
                'message': f'Key {key} not found',
                'vector_clock': self.vector_clock.get_clock()
            }
        
        return {
            'status': 'success',
            'key': key,
            'value': value,
            'vector_clock': self.vector_clock.get_clock()
        }
    
    def _handle_replication(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Handle replication messages from other nodes."""
        try:
            causal_msg = CausalMessage(
                sender_id=message['sender_id'],
                message_type='replicate',
                key=message['key'],
                value=message['value'],
                vector_clock=message['vector_clock'],
                message_id=message['message_id']
            )
            
            # Add to message buffer for causal delivery
            self.message_buffer.add_message(causal_msg)
            
            return {'status': 'received'}
        except Exception as e:
            return {'status': 'error', 'message': str(e)}
    
    def _process_causal_delivery(self):
        """Continuously process messages in causal order."""
        while self.running:
            try:
                # Get deliverable messages
                deliverable = self.message_buffer.get_deliverable_messages(self.vector_clock)
                
                for message in deliverable:
                    # Update vector clock
                    self.vector_clock.update(message.vector_clock)
                    
                    # Apply the operation
                    with self.store_lock:
                        self.data_store[message.key] = message.value
                    
                    print(f"Node {self.node_id}: Delivered message {message.message_id} "
                          f"for key {message.key} with clock {self.vector_clock}")
                
                time.sleep(0.1)  # Small delay to prevent busy waiting
            except Exception as e:
                print(f"Causal delivery error: {e}")
    
    def _replicate_to_peers(self, message: CausalMessage):
        """Send replication message to all peer nodes."""
        for peer_id, (host, port) in self.peers.items():
            if peer_id != self.node_id:
                try:
                    self._send_to_peer(host, port, {
                        'type': 'replicate',
                        'sender_id': message.sender_id,
                        'key': message.key,
                        'value': message.value,
                        'vector_clock': message.vector_clock,
                        'message_id': message.message_id
                    })
                except Exception as e:
                    print(f"Failed to replicate to peer {peer_id}: {e}")
    
    def _send_to_peer(self, host: str, port: int, message: Dict[str, Any]):
        """Send a message to a specific peer."""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((host, port))
            sock.send(json.dumps(message).encode('utf-8'))
            response = sock.recv(4096).decode('utf-8')
            sock.close()
            return json.loads(response)
        except Exception as e:
            raise Exception(f"Failed to send message: {e}")
    
    def shutdown(self):
        """Shutdown the node."""
        self.running = False
        if self.socket:
            self.socket.close()
