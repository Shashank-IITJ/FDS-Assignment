import socket
import json
import time
import threading

class KVClient:
    def __init__(self, nodes: List[tuple]):
        """
        Initialize client with list of node addresses.
        
        Args:
            nodes: List of (host, port) tuples for each node
        """
        self.nodes = nodes
        self.current_node = 0
    
    def write(self, key: str, value: str) -> Dict[str, Any]:
        """Write a key-value pair to the distributed store."""
        message = {
            'type': 'write',
            'key': key,
            'value': value
        }
        return self._send_request(message)
    
    def read(self, key: str) -> Dict[str, Any]:
        """Read a value from the distributed store."""
        message = {
            'type': 'read',
            'key': key
        }
        return self._send_request(message)
    
    def _send_request(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Send request to current node."""
        host, port = self.nodes[self.current_node]
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((host, port))
            sock.send(json.dumps(message).encode('utf-8'))
            response = sock.recv(4096).decode('utf-8')
            sock.close()
            return json.loads(response)
        except Exception as e:
            # Try next node on failure
            self.current_node = (self.current_node + 1) % len(self.nodes)
            raise Exception(f"Request failed: {e}")
    
    def test_causal_consistency(self):
        """Test scenario to verify causal consistency."""
        print("Testing causal consistency...")
        
        # Write initial value
        result1 = self.write("counter", "1")
        print(f"Write 1: {result1}")
        time.sleep(0.5)
        
        # Read and then write based on read value
        result2 = self.read("counter")
        print(f"Read: {result2}")
        
        if result2['status'] == 'success':
            new_value = str(int(result2['value']) + 1)
            result3 = self.write("counter", new_value)
            print(f"Write 2: {result3}")
        
        time.sleep(1)
        
        # Final read to verify consistency
        result4 = self.read("counter")
        print(f"Final read: {result4}")

